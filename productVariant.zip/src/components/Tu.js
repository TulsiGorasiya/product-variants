import React, { useState } from 'react'
import Select from 'react-select'

const attributesList = [
    {
        value: 'color',
        label: 'Color',
        options: [
            { value: "red", label: "Red" },
            { value: "blue", label: "Blue" },
            { value: "green", label: "Green" },
        ]
    },
    {
        value: 'size', label: 'Size',
        options: [
            { value: 'small', label: 'Small' },
            { value: 'medium', label: 'Medium' },
            { value: 'large', label: 'Large' },
        ]
    },
    {
        value: 'material', label: 'Material',
        options: [
            { value: 'leather', label: 'Leather' },
            { value: 'cotton', label: 'Cotton' },
            { value: 'polyester', label: 'Polyester' },
        ]
    }

]

function Tu() {
    const [attributes, setAttributes] = useState([]);
    const [selectedOption, setSelectedOption] = useState(null);
    const [selectedAttributeValues, setSelectedAttributeValues] = useState([]);

    // const handleChange = (selectedOption) => {
    //     setSelectedOption(selectedOption);
    // }

    // const handleClick = (selectedOption) => {
    //     if (!selectedAttributeValues.includes(selectedOption.value)) {
    //         setAttributes([...attributes, selectedOption]);
    //         setSelectedAttributeValues([...selectedAttributeValues, selectedOption.value]);
    //     }
    // }

    // const handleRemove = (index) => {
    //     const newAttributes = [...attributes];
    //     const newSelectedAttributeValues = [...selectedAttributeValues];
    //     newAttributes.pop(index);
    //     setAttributes(newAttributes);
    //     newSelectedAttributeValues.pop(index);
    //     setSelectedAttributeValues(newSelectedAttributeValues);
    // }



    return (
        <div>
            <label>Attributes</label>
            <Select options={attributesList} value={selectedOption} />
            <div>
                <button>ADD</button>
            </div>
            <div>
                {
                    attributes.map((attribute, index) => (
                        <div key={index}>
                            <label>{attribute.label}</label>
                            <Select options={attribute.options} isMulti />
                            <button >Remove</button>
                        </div>
                    ))
                }
            </div>
        </div >
    )
}
{/* onClick = {() => handleClick(selectedOption)
onClick = {() => handleRemove(index)} */}

export default Tu;
