import React, { useState } from 'react'
import Select from 'react-select'



const options = [
  { value: "color", label: "Color" },
  { value: "size", label: "Size" },
  { value: "material", label: "Material" },
];

const colorOptions = [
  { value: "red", label: "Red" },
  { value: "blue", label: "Blue" },
  { value: "green", label: "Green" },
];

const sizeOptions = [
  { value: "s", label: "S" },
  { value: "m", label: "M" },
  { value: "l", label: "L" },
];

const materialOptions = [
  { value: "cotton", label: "Cotton" },
  { value: "polyester", label: "Polyester" },
  { value: "linen", label: "Linen" },
];

function Product() {
  const [selectedOption, setSelectedOption] = useState(null);
  const [selectedAttribute, setSelectedAttribute] = useState(null);
  const [attributeValue, setAttributeValue] = useState(null);
  const handleChange = (selectedOption) => {
    setSelectedOption(selectedOption);
    console.log(selectedOption)
  }
  const handleButtonClick = (label) => {

    setSelectedOption({ value: label, label });
  };
  return (
    <div>
      <form action="">
        <div>
          {/* <label htmlFor="product">Attributes</label>
          <Select options={options} value={selectedOption} onChange={handleChange} />
          <button onClick={handleButtonClick} >ADD</button> */}
          <div>
            <label htmlFor="attribute">Attribute:</label>
            <Select
              options={options}
              value={selectedAttribute}
              onChange={(selectedOption) => setSelectedAttribute(selectedOption)}
            />
          </div>
          {selectedAttribute && (
            <div>
              <label htmlFor="attributeValue">{selectedAttribute.value}</label>
              {selectedAttribute.value === "color" && (
                <Select
                  options={colorOptions}
                  value={attributeValue}
                  onChange={(selectedOption) => setAttributeValue(selectedOption)}
                />
              )}
              {selectedAttribute.value === "size" && (
                <Select
                  options={sizeOptions}
                  value={attributeValue}
                  onChange={(selectedOption) => setAttributeValue(selectedOption)}
                />
              )}
              {selectedAttribute.value === "material" && (
                <Select
                  options={materialOptions}
                  value={attributeValue}
                  onChange={(selectedOption) => setAttributeValue(selectedOption)}
                />
              )}
            </div>)}
        </div>
        <button>Create Varient</button>
      </form>
    </div>
  )
}

export default Product
