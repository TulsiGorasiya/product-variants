import React, { useState } from 'react';
import Select from 'react-select';
const attributes = [
    {
        key: "color",
        options: [{ label: " red " }, { label: " blue " }, { label: " pink " }]
    },
    {
        key: "size",
        options: [{ label: "X" }, { label: "S" }, { label: "M" }]
    },
    {
        key: "material",
        options: [{ label: "cotton" }, { label: 'ployster' }, { label: "purecotton" }]
    }
]


const options = [
    { value: 'attributes', label: 'Attributes' },
    { value: 'variants', label: 'Variants' },
];
const menu = [
    { value: 'color', label: 'Color' },
    { value: 'size', label: 'Size' },
    { value: 'material', label: 'Material' }

]

const colorOptions = [
    { value: 'red', label: 'Red' },
    { value: 'green', label: 'Green' },
    { value: 'blue', label: 'Blue' },
];

const sizeOptions = [
    { value: 'small', label: 'Small' },
    { value: 'medium', label: 'Medium' },
    { value: 'large', label: 'Large' },
];

const materialOptions = [
    { value: 'leather', label: 'Leather' },
    { value: 'cotton', label: 'Cotton' },
    { value: 'polyester', label: 'Polyester' },
];

const Ap = () => {
    const [selectedOption, setSelectedOption] = useState();
    const [selectedMenu, setSelectedMenu] = useState();
    const [selectedColor, setSelectedColor] = useState([]);
    const [selectedSize, setSelectedSize] = useState([]);
    const [selectedMaterial, setSelectedMaterial] = useState([]);
    const [attributes, setAttributes] = useState({});

    const handleOptionChange = (selectedOption) => {
        setSelectedOption(selectedOption);
        console.log(selectedOption);
    };
    const handleMenuChange = (selectedMenu) => {
        setSelectedMenu(selectedMenu);
    }

    const handleColorChange = (selectedColor) => {
        setSelectedColor(...selectedColor);
    };

    const handleSizeChange = (selectedSize) => {
        setSelectedSize(...selectedSize);
    };

    const handleMaterialChange = (selectedMaterial) => {
        setSelectedMaterial(...selectedMaterial);
    };


    const handleClick = (e) => {
        e.preventDefault();
        console.log('handleClick');
        setSelectedOption(e.target.value);
        setAttributes({
            ...attributes,
            color: selectedColor.map(c => c.value),
            size: selectedSize.map(s => s.value),
            material: selectedMaterial.map(m => m.value)
        });
    }

    return (
        <div>
            {/* <Select options={options} onChange={handleOptionChange} /> */}
            {selectedOption && selectedOption.value === 'attributes' && (
                <div>
                    < Select options={attributes} onChange={handleMenuChange} />


                    {/* {
                        selectedOption && selectedOption.value === 'color' && (
                            <div>
                                <h1>color</h1>
                                <Select options={colorOptions} onChange={handleColorChange} isMulti />

                            </div>
                        )
                    }
                    {
                        selectedOption && selectedOption.value === 'material' && (
                            <div>
                                <h1>mareial</h1>
                                <Select options={materialOptions} onChange={handleMaterialChange} isMulti />
                            </div>
                        )
                    }
                    {
                        selectedOption && selectedOption.value === 'size' && (
                            <div>
                                <h1>size</h1>
                                <Select options={sizeOptions} onChange={handleSizeChange} isMulti />
                            </div>
                        )
                    }
                */}
                    <button>Add</button>
                </div>
            )
            }
            {
                selectedOption && selectedOption.value === 'variants' && (
                    <>
                        <button>Create Variant</button>
                    </>
                )
            }


        </div >
    );
}
export default Ap;


