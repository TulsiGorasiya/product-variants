import React, { useState } from 'react'
import Select from 'react-select'
const attributesList = [
    {
        value: 'color',
        label: 'Color',
        option: [
            { value: "red", label: "Red" },
            { value: "blue", label: "Blue" },
            { value: "green", label: "Green" },
        ],
        selectValues: [{ value: "red", label: "Red" },],
    },
    {
        value: 'size',
        label: 'Size',
        option: [
            { value: 'small', label: 'Small' },
            { value: 'medium', label: 'Medium' },
            { value: 'large', label: 'Large' },
        ],
        selectValues: [],
    },
    {
        value: 'material', label: 'Material',
        option: [
            { value: 'leather', label: 'Leather' },
            { value: 'cotton', label: 'Cotton' },
            { value: 'polyester', label: 'Polyester' },
        ],
        selectValues: [],
    }

]
function Tulsi() {
    const [attribute, setAttribute] = useState([]);
    const [selectedOptionAtt, setSelectedOptionAtt] = useState(null);
    const [selectedAttributes, setSelectedAttributes] = useState([]);
    const [selectedOptionVari, setSelectedOptionVari] = useState(null);
    const [selectedVariant, setSelectedVariant] = useState([]);
    //const [varinat, setVarinat] = useState([]);
    const handleChange = (selectedOptionAtt) => {
        setSelectedOptionAtt(selectedOptionAtt);

    }
    const isDisabled = (option) => {
        return selectedAttributes.includes(option.value)

    }
    const handleClick = (selectedOptionAtt) => {
        if (!selectedAttributes.includes(selectedOptionAtt.value)) {
            setAttribute([...attribute, selectedOptionAtt]);
            //console.log("Attributes", attribute)
            setSelectedAttributes([...selectedAttributes, selectedOptionAtt.value]);
            //console.log("selectedAttributes------1-", selectedAttributes);
        }
        //console.log("selectedAttributes 2", selectedOptionAtt);
    }
    //console.log("selectedAttributes 3", selectedAttributes);
    const handleRemove = (index) => {
        // console.log(index);
        const newAttributes = [...attribute];
        //console.log("newAttributes", newAttributes);
        const newSelectedAttributes = [...selectedAttributes];
        //console.log("newSelectedAttributes", newSelectedAttributes);
        newAttributes.splice(index, 1);
        //console.log("newAttributes 1", newAttributes);
        newSelectedAttributes.splice(index, 1);
        //console.log("newselectedAttributes", newSelectedAttributes)
        setAttribute(newAttributes);
        //console.log("attribute", attribute)
        setSelectedAttributes(newSelectedAttributes);
    }
    // const onChangeOption = (selectedVariantOption) => {

    //     console.log('onChangeOption', selectedVariantOption)
    //     const key = selectedVariantOption.value;
    //     console.log("key", key);
    //     setSelectedVariant(
    //         ...selectedVariant,
    //         [key]: selectedVariantOption
    //     );
    //     console.log("selected option", selectedOptionAtt);
    //     console.log("selectedVariant option", selectedVariant);
    // }
    const onChangeOptionVari = (value) => {
        console.log("value-------", value)
        // this.setState({ 
        //     data: {
        //       ...this.state.data, 
        //       categories: selectedOptions
        //     }
        //   })
        // console.log("opop", opop);
        // console.log("tulsiiiiii", value)
        // const updatedAttributesList = [...attribute];
        // updatedAttributesList[index].selectValues = opop;
        // setAttribute(updatedAttributesList);
        //console.log("values", selectedOptionVari.value);

        //console.log('onChangeOption', selectedOptionVari.value)

        // const handleSelect = (value, selectedOption, index) => {
        //     const updatedAttributesList = [...attributesList];
        //     updatedAttributesList[index].selectValues = selectedOption;
        //     setAttributesList(updatedAttributesList);
        //   };

        // const key = selectedOptionVari;
        // console.log("key", key);
        // setSelectedVariant({
        //     ...selectedVariant,
        //     [key]: selectedOptionVari
        // });

        //console.log("selected option", selectedOptionVari);
        //console.log("selected========Variant", selectedVariant);
        // console.log("onChangeOptionVari", selectedOptionVari);
        setSelectedOptionVari(selectedOptionVari);
        // console.log("selectedOptionVari", selectedOptionVari)
        //console.log('selectedOptionAtt', selectedOptionAtt);
    }
    console.log("values------", selectedOptionVari);
    // const onSaveclick = (selectedOptionVari) => {
    //     // if (!selectedVariant.includes(selectedOptionVari.value)) {
    //     //     setVarinat([...attribute, selectedOptionVari]);
    //     //     console.log("variant", varinat)
    //     //     setSelectedVariant([...selectedVariant, selectedOptionVari.value]);
    //     //     console.log("selectedvarinat------1-", selectedVariant);
    //     // }
    //     console.log("save button", selectedOptionVari)
    // }


    //   const onClear = () => {
    //     selectInputRef.current.select.clearValue();
    //   };
    // const [attribute, setAttribute] = useState([]);
    // const [selectedOptionAtt, setSelectedOptionAtt] = useState(null);
    // const [selectedAttributes, setSelectedAttributes] = useState([]);
    // const [selectedOptionVari, setSelectedOptionVari] = useState(null);
    // const [selectedVariant, setSelectedVariant] = useState([]);
    console.log("attributes", attribute);
    console.log("selectedOptionAtt", selectedOptionAtt);
    console.log("selecedAttributes", selectedAttributes);
    console.log("selecetdOptionvari", selectedOptionVari);
    console.log("selectedVarinat", selectedVariant);
    return (
        <div>
            <div>
                <label htmlFor="attri">Attributes</label>

                <Select options={attributesList} onChange={handleChange} value={selectedOptionAtt} clearable={true} isOptionDisabled={(option) => isDisabled(option)} />
            </div>
            <div>
                <button onClick={() => handleClick(selectedOptionAtt)}>ADD</button>
            </div>
            <div style={{ border: "solid" }}>
                {
                    attribute.map((att, index) => (
                        <>
                            <div key={index}>
                                <label>{att.label}</label>
                                <div key={index}>
                                    <Select className={att.label} id={att.label} options={att.option}
                                        onChange={(event) => onChangeOptionVari(event.target.value)} value={ }isMulti={true} />
                                </div>
                                {/* {console.log(att.selectedOptionVari)}
                                {console.log(selectedOptionVari)
                                } */}
                                <button onClick={() => handleRemove(index)}>Remove</button>
                            </div>
                        </>
                    ))
                }

            </div>
            <div>
                <button>Save</button>
            </div>
        </div >

    )
}


export default Tulsi
