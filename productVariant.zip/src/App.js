
import './App.css';
//import Tu from './components/Tu';
import Tulsi from './components/Tulsi';
//import Tulsii from './components/Tulsii';
//import Ap from './components/Ap';
//import Product from './components/Product';


function App() {
  return (
    <div>
      {/* <Product /> */}
      {/* <Ap /> */}
      <Tulsi />
      {/* <Tu /> */}
      {/* <Tulsii /> */}
    </div>
  );
}

export default App;
